CREATE VIEW view_yaddas_no_replies AS
  SELECT
    `y`.`YaddaID`     AS `YaddaID`,
    `y`.`Text`        AS `Text`,
    `y`.`Username`    AS `Username`,
    `y`.`DateAndTime` AS `DateAndTime`
  FROM `c1db2`.`Yadda` `y`
  WHERE (NOT (`y`.`YaddaID` IN (SELECT `r`.`YaddaIDReply`
                                FROM `c1db2`.`Reply` `r`)))
  ORDER BY `y`.`DateAndTime`, `y`.`YaddaID`;
